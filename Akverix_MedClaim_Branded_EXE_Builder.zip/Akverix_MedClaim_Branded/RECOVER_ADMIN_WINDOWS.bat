@echo off
cd /d "%~dp0"
py recover_admin.py
pause
