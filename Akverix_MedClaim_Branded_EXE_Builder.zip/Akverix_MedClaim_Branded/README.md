# Akverix MedClaim — Insurance Patient Billing (Starter Application)

## Windows installation
1. Install Python 3.11 or newer from python.org (select **Add Python to PATH**).
2. Extract this ZIP to a folder on your Windows PC.
3. Double-click `start_windows.bat`. Internet is required for the first Flask installation.
4. Read the terminal's **INITIAL LOGIN** username/password, which are printed only when the database is first created.
5. Open `http://127.0.0.1:5000/login` in your browser.
6. Sign in and immediately change the password from the Password menu.

## Features
- Insurance-only registration: IP and day care.
- Direct insurer vs third-party administrator (TPA), with insurer name in both cases.
- Itemized bill, printable invoice, approved and settled amounts.
- Discharge summaries, lab reports and other attachments (PDF, DOC, DOCX, JPG, PNG, WEBP).
- Filtered patient reports by date, name, insurance company, patient category and insurance arrangement; CSV/Excel and browser print-to-PDF.
- SQLite database, persistent attachments and authenticated file downloads.

## Data & backup
- Database: `data/hospital.db`
- Attachments: `data/uploads/`
- **Back up the entire `data` folder**, with the application stopped, to an encrypted, access-controlled location. Do not delete or overwrite this folder when upgrading.
- You may set `HOSPITAL_DATA_DIR` to a separate secure folder for persistent data storage.

## Important security and deployment limitations
This is a **local single-user starter application**, not a production-ready hospital information system. It has basic password authentication, but does **not** yet implement granular role permissions, audit logging, encryption at rest, CSRF protection, malware scanning, concurrent user management, or validated clinical record retention workflows. Keep it bound to localhost. Do **not** expose it to the internet, a shared hospital network, or real patient data without a professional security and compliance review and appropriate enhancements. Avoid entering actual patient health information while evaluating the prototype. Invoice format, GST and insurer-specific claim requirements must be verified before operational use.
