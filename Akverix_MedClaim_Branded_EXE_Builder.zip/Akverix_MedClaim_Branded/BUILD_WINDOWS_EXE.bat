@echo off
setlocal
cd /d "%~dp0"
echo =============================================
echo  Akverix MedClaim - Windows EXE Builder
echo =============================================
where py >nul 2>nul
if errorlevel 1 (
  echo Python launcher not found. Install Python 3.11 or newer from python.org.
  pause
  exit /b 1
)
py -m venv .build_venv
if errorlevel 1 goto fail
call .build_venv\Scripts\activate.bat
python -m pip install --upgrade pip
if errorlevel 1 goto fail
python -m pip install -r requirements.txt
if errorlevel 1 goto fail
python -m PyInstaller --noconfirm --clean --onefile --console --add-data "assets;assets" --name AkverixMedClaim app.py
if errorlevel 1 goto fail
echo.
echo SUCCESS: dist\AkverixMedClaim.exe
echo You may copy this EXE to another Windows PC.
echo The app stores its database and uploads in %%LOCALAPPDATA%%\AkverixMedClaim.
pause
exit /b 0
:fail
echo.
echo BUILD FAILED. See the error above.
pause
exit /b 1
