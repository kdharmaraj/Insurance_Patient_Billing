import os,sqlite3,getpass,sys
from werkzeug.security import generate_password_hash
base=os.environ.get('HOSPITAL_DATA_DIR') or os.path.join(os.environ.get('LOCALAPPDATA',os.path.dirname(__file__)),'AkverixMedClaim')
db=os.path.join(base,'hospital.db')
if not os.path.isfile(db):sys.exit('No existing database. Run application first.')
with sqlite3.connect(db) as c:
 names=[r[0] for r in c.execute("SELECT username FROM users WHERE role='admin'")]
 if not names:sys.exit('No administrator yet; use /setup.')
 print('Admins:',', '.join(names));name=input('Username to reset: ').strip()
 if name not in names:sys.exit('Unknown administrator.')
 p=getpass.getpass('New password (12+ characters): ');q=getpass.getpass('Confirm: ')
 if not 12<=len(p)<=128 or p!=q:sys.exit('Password mismatch or invalid length.')
 c.execute("UPDATE users SET password=? WHERE username=? AND role='admin'",(generate_password_hash(p),name))
 print('Password updated. Patient records preserved.')
