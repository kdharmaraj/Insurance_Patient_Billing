import os, sys, sqlite3, csv, io, secrets, uuid
from datetime import datetime
from functools import wraps
from flask import Flask, request, redirect, url_for, session, render_template_string, send_file, send_from_directory, flash, abort, Response
from werkzeug.security import generate_password_hash, check_password_hash
from werkzeug.utils import secure_filename
from markupsafe import Markup

BASE=os.path.dirname(os.path.abspath(__file__))
DATA=os.environ.get('HOSPITAL_DATA_DIR') or os.path.join(os.environ.get('LOCALAPPDATA',BASE),'AkverixMedClaim')
os.makedirs(DATA,exist_ok=True)
UPLOADS=os.path.join(DATA,'uploads');os.makedirs(UPLOADS,exist_ok=True)
DB=os.path.join(DATA,'hospital.db')
ASSET_DIR=os.path.join(getattr(sys,'_MEIPASS',BASE),'assets')
app=Flask(__name__);app.secret_key=os.environ.get('APP_SECRET_KEY') or secrets.token_hex(32)
app.config['MAX_CONTENT_LENGTH']=20*1024*1024
ALLOWED={'pdf','png','jpg','jpeg','webp','doc','docx'}


@app.route('/brand/<name>')
def brand_asset(name):
 if name != 'akverix_logo.webp':abort(404)
 return send_from_directory(ASSET_DIR,name,max_age=86400)

def conn():
 c=sqlite3.connect(DB);c.row_factory=sqlite3.Row;c.execute('PRAGMA foreign_keys=ON');return c

def init():
 with conn() as c:
  c.executescript('''CREATE TABLE IF NOT EXISTS users(id INTEGER PRIMARY KEY,username TEXT UNIQUE,password TEXT,role TEXT);
 CREATE TABLE IF NOT EXISTS patients(id INTEGER PRIMARY KEY,uhid TEXT,patient_name TEXT NOT NULL,age TEXT,gender TEXT,phone TEXT,admission_type TEXT,admission_date TEXT,discharge_date TEXT,department TEXT,doctor TEXT,procedure_name TEXT,insurance_type TEXT,insurer TEXT,tpa TEXT,policy_number TEXT,member_id TEXT,claim_number TEXT,preauth_number TEXT,claim_status TEXT DEFAULT 'Registered',approved_amount REAL DEFAULT 0,settled_amount REAL DEFAULT 0,notes TEXT,created_at TEXT);
 CREATE TABLE IF NOT EXISTS charges(id INTEGER PRIMARY KEY,patient_id INTEGER NOT NULL,description TEXT NOT NULL,amount REAL NOT NULL,created_at TEXT,FOREIGN KEY(patient_id) REFERENCES patients(id));
 CREATE TABLE IF NOT EXISTS documents(id INTEGER PRIMARY KEY,patient_id INTEGER NOT NULL,category TEXT,original_name TEXT,stored_name TEXT,uploaded_at TEXT,FOREIGN KEY(patient_id) REFERENCES patients(id));
 CREATE INDEX IF NOT EXISTS idx_patient_name ON patients(patient_name);CREATE INDEX IF NOT EXISTS idx_insurer ON patients(insurer);CREATE INDEX IF NOT EXISTS idx_admission_date ON patients(admission_date);''')

init()

def login_required(fn):
 @wraps(fn)
 def inner(*a,**kw):
  if not session.get('uid'):return redirect(url_for('login'))
  return fn(*a,**kw)
 return inner

def money(n):return '₹{:,.2f}'.format(float(n or 0))
app.jinja_env.filters['money']=money
BASE_HTML='''<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>{{title}} | Akverix MedClaim</title><style>
:root{--blue:#155eef;--navy:#122b55;--teal:#08a99b;--bg:#f1f6ff;--line:#dfe8f6;--ink:#1b3151}*{box-sizing:border-box}body{margin:0;font-family:Inter,Segoe UI,Arial,sans-serif;background:var(--bg);color:var(--ink)}a{text-decoration:none;color:var(--blue)}.layout{display:flex;min-height:100vh}.side{width:244px;flex-shrink:0;background:linear-gradient(170deg,#102b60,#174d91);padding:26px 16px;color:white}.brand{font-size:21px;font-weight:850;margin:0 8px 8px}.tag{font-size:11px;color:#a9d6ff;margin:0 8px 28px}.nav{display:block;color:#e6f2ff;padding:13px 14px;border-radius:11px;margin:4px 0;font-weight:600}.nav:hover,.nav.active{background:#ffffff26}.main{padding:27px 34px;flex:1;min-width:0}.top{display:flex;justify-content:space-between;align-items:center;gap:10px;margin-bottom:22px}.top h1{font-size:27px;margin:0}.muted{color:#7183a0;font-size:13px}.card{background:white;border:1px solid var(--line);border-radius:17px;box-shadow:0 5px 24px #1a4e8b0a;padding:22px;margin-bottom:18px}.metrics{display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:15px}.metric{background:white;border:1px solid var(--line);border-radius:16px;padding:20px;border-top:4px solid var(--blue)}.metric:nth-child(2){border-color:var(--teal)}.metric:nth-child(3){border-color:#f0a339}.metric:nth-child(4){border-color:#a26ee6}.metric b{display:block;font-size:25px;margin:12px 0 3px}.btn{display:inline-block;background:var(--blue);color:white;border:0;border-radius:9px;padding:10px 15px;font-weight:700;cursor:pointer;font-size:13px}.btn.alt{background:#e7f0ff;color:#1750ad}.btn.teal{background:var(--teal)}.btn.danger{background:#b63851}.actions{display:flex;gap:8px;flex-wrap:wrap}.grid{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:15px}.field label{display:block;font-size:12px;font-weight:750;margin-bottom:7px;color:#4b6384}.field input,.field select,.field textarea{width:100%;padding:11px;border:1px solid #d5e0ee;border-radius:9px;background:#fbfdff;color:#1b3151;font:inherit;font-size:14px}.field textarea{min-height:72px}.wide{grid-column:1/-1}.section{font-size:16px;font-weight:800;color:#184b91;margin:10px 0 0}.table-wrap{overflow-x:auto}table{width:100%;border-collapse:collapse;white-space:nowrap}th{text-align:left;font-size:12px;color:#5d7497;background:#f3f7ff;padding:12px}td{padding:13px 12px;border-bottom:1px solid #edf1f8;font-size:13px}.pill{background:#e9f5ff;color:#165aa5;padding:5px 9px;border-radius:30px;font-size:11px;font-weight:700}.notice{background:#e8f8f5;color:#11665e;border-radius:9px;padding:11px 15px;margin-bottom:16px}.small{font-size:12px}.login-bg{min-height:100vh;display:grid;place-items:center;background:linear-gradient(140deg,#102e65,#1663a7,#0aada2)}.login{width:min(420px,92vw);padding:35px;background:white;border-radius:23px;box-shadow:0 20px 80px #06264d55}.login h1{margin:0 0 8px}.login .field{margin:17px 0}@media(max-width:1050px){.metrics{grid-template-columns:repeat(2,1fr)}.grid{grid-template-columns:repeat(2,1fr)}}@media(max-width:700px){.layout{display:block}.side{width:100%;padding:15px}.brand{font-size:18px}.tag{margin-bottom:10px}.side nav{display:flex;overflow-x:auto}.nav{white-space:nowrap;padding:9px}.main{padding:17px}.top{align-items:flex-start}.top h1{font-size:21px}.grid{grid-template-columns:1fr}.metrics{grid-template-columns:repeat(2,1fr)}.metric{padding:12px}.metric b{font-size:19px}}@media print{.side,.btn,.actions,.filters{display:none!important}.main{padding:0}.card{box-shadow:none;border:0}}

/* Akverix healthcare brand */
.side{background:linear-gradient(165deg,#071d3d 0%,#103f80 65%,#0874ac 100%);box-shadow:8px 0 35px #05244d18}
.brand-lockup{padding:6px 7px 16px;margin-bottom:10px;border-bottom:1px solid #ffffff30}
.brand-lockup img{display:block;width:100%;max-height:74px;object-fit:contain;border-radius:6px}
.brand-lockup strong{display:block;margin-top:9px;font-size:18px;letter-spacing:-.3px}
.brand-lockup small{display:block;color:#b2eaff;margin-top:5px;font-size:11px}
.login-bg{position:relative;isolation:isolate;padding:34px 18px;overflow:hidden;background:radial-gradient(ellipse at 5% 30%,#118be3 0%,transparent 42%),radial-gradient(ellipse at 95% 85%,#06b9dc 0%,transparent 40%),linear-gradient(125deg,#04142d,#08366f 65%,#0074b2)}
.login-bg:before{content:'+';position:absolute;right:9%;top:7%;font-size:145px;font-weight:900;color:#4abaff22;z-index:-1}
.login-bg:after{content:'';position:absolute;bottom:-26%;left:-10%;width:120%;height:50%;border:3px solid #00d8ff6b;border-radius:50%;transform:rotate(-9deg);z-index:-1}
.auth-shell{width:min(590px,96vw);position:relative;z-index:1}
.auth-logo{display:block;width:min(410px,88%);height:auto;max-height:138px;object-fit:contain;margin:0 auto 18px;filter:drop-shadow(0 8px 16px #0005)}
.login{width:100%;padding:34px 42px 28px;border:1px solid #b3e9ff;background:linear-gradient(145deg,#f4faff,#fff 62%,#e8f7ff);box-shadow:0 22px 70px #00142c77,0 0 0 3px #20d9ff33;border-radius:28px}
.auth-heading{display:flex;align-items:center;justify-content:center;gap:13px;margin-bottom:6px}
.auth-heading .hospital-icon{display:grid;place-items:center;width:53px;height:53px;border-radius:15px;background:linear-gradient(135deg,#13c7ed,#155eef);font-size:34px;color:white;box-shadow:0 5px 15px #117acb50}
.auth-heading h1{margin:0;font-size:clamp(25px,4vw,34px);letter-spacing:-1px;color:#102f66}
.auth-sub{text-align:center;color:#536987;margin:0 0 21px;font-size:15px}
.login .field{margin:14px 0}.login .field label{font-size:13px;color:#294b78}
.login .field input{height:49px;background:white;border:1px solid #c2d8ed;font-size:15px}
.login .field input:focus{outline:2px solid #38bdf8;border-color:#155eef}
.auth-submit{width:100%;padding:15px 18px;margin-top:8px;background:linear-gradient(105deg,#05bde9,#155eef 70%,#063d9e);font-size:15px;border-radius:12px;transition:transform .2s,filter .2s}
.auth-submit:hover{filter:brightness(1.1);transform:translateY(-2px)}
.auth-footer{text-align:center;margin-top:18px;font-size:12px;color:#627999}
.auth-footer a{font-weight:700}
@media(max-width:600px){.login{padding:26px 20px}.auth-heading .hospital-icon{width:43px;height:43px;font-size:28px}.auth-heading h1{font-size:25px}.auth-logo{max-height:100px}}
</style></head><body>{% if session.uid %}<div class="layout"><aside class="side"><div class="brand-lockup"><img src="/brand/akverix_logo.webp" alt="Akverix Technologies logo"><strong>✚ Akverix MedClaim</strong><small>Insurance Billing Suite</small></div><nav><a class="nav" href="{{url_for('dashboard')}}">▦ Dashboard</a><a class="nav" href="{{url_for('patients')}}">♧ Patients</a><a class="nav" href="{{url_for('new_patient')}}">＋ New Registration</a><a class="nav" href="{{url_for('reports')}}">▤ Reports</a><a class="nav" href="{{url_for('change_password')}}">⚙ Password</a><a class="nav" href="{{url_for('logout')}}">↪ Sign out</a></nav></aside><main class="main"><div class="top"><div><h1>{{title}}</h1><div class="muted">Akverix Technologies · Insurance patients only</div></div><div class="muted">{{session.username}}</div></div>{% with msgs=get_flashed_messages() %}{% for m in msgs %}<div class="notice">{{m}}</div>{% endfor %}{% endwith %}{{content|safe}}</main></div>{% else %}<div class="login-bg"><div class="auth-shell"><img class="auth-logo" src="/brand/akverix_logo.webp" alt="Akverix Technologies">{{content|safe}}</div></div>{% endif %}</body></html>'''
def page(title,template,**kw):
 content=render_template_string(template,**kw)
 return render_template_string(BASE_HTML,title=title,content=Markup(content))

def admin_exists():
 with conn() as c:return bool(c.execute("SELECT 1 FROM users WHERE role='admin' LIMIT 1").fetchone())

@app.route('/')
@app.route('/welcome')
def welcome():
 if admin_exists():return redirect(url_for('login'))
 return page('Welcome','<div class="login"><div class="auth-heading"><span class="hospital-icon" aria-hidden="true">✚</span><h1>Akverix MedClaim</h1></div><h2 style="text-align:center;font-size:19px">First-time Administrator Setup</h2><p class="auth-sub">Create your administrator login before using the application.</p><a class="btn auth-submit" style="display:block;text-align:center" href="/setup">Create Admin Account</a></div>')

@app.route('/setup',methods=['GET','POST'])
def setup_admin():
 if admin_exists():return redirect(url_for('login'))
 if request.method=='POST':
  username=request.form.get('username','').strip();password=request.form.get('password','');confirm=request.form.get('confirm','')
  if not (3<=len(username)<=40) or not all(x.isalnum() or x in '._-' for x in username):flash('Invalid username (3-40 letters/numbers/._-).')
  elif not 12<=len(password)<=128:flash('Password must be 12-128 characters.')
  elif password!=confirm:flash('Passwords do not match.')
  else:
   try:
    with conn() as c:
     c.execute("INSERT INTO users(username,password,role) SELECT ?,?,'admin' WHERE NOT EXISTS(SELECT 1 FROM users WHERE role='admin')",(username,generate_password_hash(password)))
     created=c.execute('SELECT changes()').fetchone()[0]
    if created:flash('Admin account created. Please sign in.');return redirect(url_for('login'))
   except sqlite3.IntegrityError:flash('Username already exists.')
   if admin_exists():return redirect(url_for('login'))
 return page('Create administrator','''<div class="login"><div class="auth-heading"><span class="hospital-icon" aria-hidden="true">✚</span><h1>Akverix MedClaim</h1></div><p class="auth-sub">First-time administrator setup</p>{% with msgs=get_flashed_messages() %}{% for m in msgs %}<div class="notice">{{m}}</div>{% endfor %}{% endwith %}<form method="post"><div class="field"><label>Admin username</label><input name="username" minlength="3" maxlength="40" required></div><div class="field"><label>Password (12+ characters)</label><input name="password" type="password" minlength="12" required></div><div class="field"><label>Confirm password</label><input name="confirm" type="password" minlength="12" required></div><button class="btn auth-submit">Create administrator</button></form></div>''')

@app.route('/login',methods=['GET','POST'])
def login():
 if not admin_exists():return redirect(url_for('welcome'))
 if request.method=='POST':
  with conn() as c:u=c.execute('SELECT * FROM users WHERE username=?',(request.form.get('username',''),)).fetchone()
  if u and check_password_hash(u['password'],request.form.get('password','')):
   session.clear();session.update(uid=u['id'],username=u['username']);return redirect(url_for('dashboard'))
  flash('Invalid username or password')
 return page('Login','''<div class="login"><div class="auth-heading"><span class="hospital-icon" aria-hidden="true">✚</span><h1>Akverix MedClaim</h1></div><p class="auth-sub">Insurance Billing Suite · Secure hospital billing</p>{% with msgs=get_flashed_messages() %}{% for m in msgs %}<div class="notice">{{m}}</div>{% endfor %}{% endwith %}<form method="post"><div class="field"><label>Username</label><input name="username" required autocomplete="username"></div><div class="field"><label>Password</label><input name="password" type="password" required autocomplete="current-password"></div><button class="btn auth-submit">Sign in</button></form><div class="auth-footer">Powered by Akverix Technologies</div></div>''')
@app.route('/logout')
def logout():session.clear();return redirect(url_for('login'))
@app.route('/password',methods=['GET','POST'])
@login_required
def change_password():
 if request.method=='POST':
  with conn() as c:
   u=c.execute('SELECT * FROM users WHERE id=?',(session['uid'],)).fetchone()
   if not check_password_hash(u['password'],request.form.get('old','')):flash('Current password incorrect')
   elif len(request.form.get('new',''))<12:flash('New password must have at least 12 characters')
   else:c.execute('UPDATE users SET password=? WHERE id=?',(generate_password_hash(request.form['new']),session['uid']));flash('Password updated')
 return page('Change password','''<div class="card" style="max-width:540px"><form method="post"><div class="field"><label>Current password</label><input type="password" name="old" required></div><br><div class="field"><label>New password (12+ characters)</label><input type="password" name="new" minlength="12" required></div><br><button class="btn">Update password</button></form></div>''')
@app.route('/')
@login_required
def dashboard():
 with conn() as c:
  r=c.execute('SELECT COUNT(*) total,SUM(CASE WHEN admission_type="IP" THEN 1 ELSE 0 END) ip,SUM(CASE WHEN admission_type="Day Care" THEN 1 ELSE 0 END) daycare,SUM(CASE WHEN claim_status NOT IN ("Settled","Rejected") THEN 1 ELSE 0 END) pending FROM patients').fetchone()
  recent=c.execute('SELECT * FROM patients ORDER BY id DESC LIMIT 8').fetchall()
 return page('Dashboard','''<div class="metrics"><div class="metric">Total insurance patients<b>{{r['total']}}</b><span class="muted">Registered cases</span></div><div class="metric">Inpatient admissions<b>{{r['ip'] or 0}}</b><span class="muted">IP cases</span></div><div class="metric">Day care procedures<b>{{r['daycare'] or 0}}</b><span class="muted">Day care cases</span></div><div class="metric">Open claims<b>{{r['pending'] or 0}}</b><span class="muted">Not settled or rejected</span></div></div><div class="card" style="margin-top:20px"><div class="top"><h3>Recent patients</h3><a class="btn" href="{{url_for('new_patient')}}">+ Register Patient</a></div><div class="table-wrap"><table><tr><th>Patient</th><th>UHID</th><th>Type</th><th>Insurance</th><th>Status</th><th></th></tr>{% for p in recent %}<tr><td>{{p.patient_name}}</td><td>{{p.uhid or '-'}}</td><td>{{p.admission_type}}</td><td>{{p.insurer}}</td><td><span class="pill">{{p.claim_status}}</span></td><td><a href="{{url_for('patient_detail',pid=p.id)}}">Open →</a></td></tr>{% endfor %}</table></div></div>''',r=r,recent=recent)
FIELDS=['uhid','patient_name','age','gender','phone','admission_type','admission_date','discharge_date','department','doctor','procedure_name','insurance_type','insurer','tpa','policy_number','member_id','claim_number','preauth_number','claim_status','approved_amount','settled_amount','notes']
FORM='''<form method="post" class="card"><div class="grid"><div class="section wide">Patient & treatment information</div>{% for name,label,kind in patient_fields %}<div class="field"><label>{{label}}</label>{% if kind=='select_admission' %}<select name="{{name}}"><option value="IP" {% if p and p[name]=='IP' %}selected{% endif %}>Inpatient (IP)</option><option value="Day Care" {% if p and p[name]=='Day Care' %}selected{% endif %}>Day Care</option></select>{% elif kind=='select_gender' %}<select name="{{name}}">{% for v in ['','Male','Female','Other'] %}<option {% if p and p[name]==v %}selected{% endif %}>{{v}}</option>{% endfor %}</select>{% else %}<input name="{{name}}" type="{{kind}}" value="{{p[name] if p and p[name] is not none else ''}}" {% if name=='patient_name' %}required{% endif %}></div>{% endif %}{% if kind.startswith('select') %}</div>{% endif %}{% endfor %}<div class="section wide">Insurance & claims</div>{% for name,label,kind in insurance_fields %}<div class="field"><label>{{label}}</label>{% if kind=='insurance' %}<select name="{{name}}"><option value="Direct" {% if p and p[name]=='Direct' %}selected{% endif %}>Direct Insurance</option><option value="TPA" {% if p and p[name]=='TPA' %}selected{% endif %}>Third Party (TPA)</option></select>{% elif kind=='status' %}<select name="{{name}}">{% for v in statuses %}<option {% if p and p[name]==v %}selected{% endif %}>{{v}}</option>{% endfor %}</select>{% else %}<input name="{{name}}" type="{{kind}}" value="{{p[name] if p and p[name] is not none else ''}}"></div>{% endif %}{% if kind in ['insurance','status'] %}</div>{% endif %}{% endfor %}<div class="field wide"><label>Notes</label><textarea name="notes">{{p.notes if p else ''}}</textarea></div></div><br><button class="btn">Save patient</button> <a class="btn alt" href="{{url_for('patients')}}">Cancel</a></form>'''
PATIENT_FIELDS=[('uhid','Hospital UHID','text'),('patient_name','Patient name *','text'),('age','Age','text'),('gender','Gender','select_gender'),('phone','Phone','text'),('admission_type','Admission category','select_admission'),('admission_date','Admission / procedure date','date'),('discharge_date','Discharge date','date'),('department','Department','text'),('doctor','Consultant doctor','text'),('procedure_name','Procedure / treatment','text')]
INSURANCE_FIELDS=[('insurance_type','Insurance arrangement','insurance'),('insurer','Insurance company name','text'),('tpa','TPA name (if applicable)','text'),('policy_number','Policy number','text'),('member_id','Member ID','text'),('claim_number','Claim number','text'),('preauth_number','Preauthorization number','text'),('claim_status','Claim status','status'),('approved_amount','Approved amount (₹)','number'),('settled_amount','Settled amount (₹)','number')]
STATUSES=['Registered','Preauthorization Pending','Preauthorized','Submitted','Query Raised','Approved','Rejected','Partially Settled','Settled']
def patient_form(pid=None):
 with conn() as c:p=c.execute('SELECT * FROM patients WHERE id=?',(pid,)).fetchone() if pid else None
 if pid and not p:abort(404)
 if request.method=='POST':
  values=[request.form.get(f,'').strip() for f in FIELDS]
  if not request.form.get('patient_name','').strip() or not request.form.get('insurer','').strip():flash('Patient and insurer names are required');return redirect(request.url)
  for f in ('approved_amount','settled_amount'):
   i=FIELDS.index(f)
   try:values[i]=max(0,float(values[i] or 0))
   except ValueError:flash('Invalid monetary amount');return redirect(request.url)
  with conn() as c:
   if pid:c.execute('UPDATE patients SET '+','.join(f+'=?' for f in FIELDS)+' WHERE id=?',values+[pid])
   else:
    cur=c.execute('INSERT INTO patients('+','.join(FIELDS)+',created_at) VALUES('+','.join(['?']*(len(FIELDS)+1))+')',values+[datetime.now().isoformat(timespec='seconds')]);pid=cur.lastrowid
  flash('Patient saved');return redirect(url_for('patient_detail',pid=pid))
 return page('Edit patient' if pid else 'Register insurance patient',FORM,p=p,patient_fields=PATIENT_FIELDS,insurance_fields=INSURANCE_FIELDS,statuses=STATUSES)
@app.route('/patients/new',methods=['GET','POST'])
@login_required
def new_patient():return patient_form()
@app.route('/patients/<int:pid>/edit',methods=['GET','POST'])
@login_required
def edit_patient(pid):return patient_form(pid)
@app.route('/patients')
@login_required
def patients():
 q=request.args.get('q','').strip()
 with conn() as c:rows=c.execute('SELECT * FROM patients WHERE patient_name LIKE ? OR uhid LIKE ? OR insurer LIKE ? OR claim_number LIKE ? ORDER BY id DESC LIMIT 500',tuple(['%'+q+'%']*4)).fetchall()
 return page('Insurance patients','''<div class="card"><form class="actions" method="get"><input style="flex:1;min-width:190px;padding:11px;border:1px solid #d5e0ee;border-radius:9px" name="q" value="{{q}}" placeholder="Search patient, UHID, insurer, claim"><button class="btn">Search</button><a class="btn teal" href="{{url_for('new_patient')}}">+ New Patient</a></form></div><div class="card table-wrap"><table><tr><th>Patient</th><th>UHID</th><th>Admission</th><th>Date</th><th>Insurance company</th><th>Arrangement</th><th>Claim status</th><th></th></tr>{% for p in rows %}<tr><td><b>{{p.patient_name}}</b></td><td>{{p.uhid or '-'}}</td><td>{{p.admission_type}}</td><td>{{p.admission_date}}</td><td>{{p.insurer}}</td><td>{{p.insurance_type}}</td><td><span class="pill">{{p.claim_status}}</span></td><td><a href="{{url_for('patient_detail',pid=p.id)}}">Details →</a></td></tr>{% endfor %}</table><p class="muted">Showing up to 500 matching cases.</p></div>''',q=q,rows=rows)
@app.route('/patients/<int:pid>')
@login_required
def patient_detail(pid):
 with conn() as c:
  p=c.execute('SELECT * FROM patients WHERE id=?',(pid,)).fetchone()
  if not p:abort(404)
  charges=c.execute('SELECT * FROM charges WHERE patient_id=? ORDER BY id DESC',(pid,)).fetchall();docs=c.execute('SELECT * FROM documents WHERE patient_id=? ORDER BY id DESC',(pid,)).fetchall()
 total=sum(x['amount'] for x in charges)
 return page('Patient case #'+str(pid),'''<div class="actions" style="margin-bottom:17px"><a class="btn" href="{{url_for('edit_patient',pid=p.id)}}">Edit patient / claim</a><a class="btn alt" href="{{url_for('invoice',pid=p.id)}}" target="_blank">Print invoice</a><a class="btn alt" href="{{url_for('patients')}}">Back to patients</a></div><div class="card"><h2>{{p.patient_name}} <span class="pill">{{p.admission_type}}</span></h2><div class="grid"><div><b>UHID</b><p>{{p.uhid or '-'}}</p></div><div><b>Admission date</b><p>{{p.admission_date or '-'}}</p></div><div><b>Discharge date</b><p>{{p.discharge_date or '-'}}</p></div><div><b>Insurance company</b><p>{{p.insurer}}</p></div><div><b>Insurance type / TPA</b><p>{{p.insurance_type}} / {{p.tpa or '-'}}</p></div><div><b>Claim status</b><p>{{p.claim_status}}</p></div><div><b>Policy number</b><p>{{p.policy_number or '-'}}</p></div><div><b>Claim number</b><p>{{p.claim_number or '-'}}</p></div><div><b>Approved</b><p>{{p.approved_amount|money}}</p></div></div></div><div class="card"><h3>Patient bill <span class="pill">Total {{total|money}}</span></h3><div class="table-wrap"><table><tr><th>Charge description</th><th>Amount</th><th></th></tr>{% for x in charges %}<tr><td>{{x.description}}</td><td>{{x.amount|money}}</td><td><form method="post" action="{{url_for('delete_charge',cid=x.id)}}" onsubmit="return confirm('Remove this charge?')"><button class="btn danger">Remove</button></form></td></tr>{% endfor %}</table></div><form method="post" action="{{url_for('add_charge',pid=p.id)}}" class="grid" style="margin-top:18px"><div class="field"><label>Charge description</label><input name="description" required placeholder="Room / Procedure / Lab"></div><div class="field"><label>Amount (₹)</label><input name="amount" type="number" min="0" step="0.01" required></div><div style="align-self:end"><button class="btn teal">Add charge</button></div></form></div><div class="card"><h3>Discharge summaries, lab reports & claim documents</h3><div class="table-wrap"><table><tr><th>Category</th><th>File</th><th>Uploaded</th><th></th></tr>{% for d in docs %}<tr><td>{{d.category}}</td><td><a href="{{url_for('download_document',did=d.id)}}">{{d.original_name}}</a></td><td>{{d.uploaded_at}}</td><td><form method="post" action="{{url_for('delete_document',did=d.id)}}" onsubmit="return confirm('Delete this document?')"><button class="btn danger">Delete</button></form></td></tr>{% endfor %}</table></div><form method="post" enctype="multipart/form-data" action="{{url_for('upload_document',pid=p.id)}}" class="grid" style="margin-top:18px"><div class="field"><label>Document category</label><select name="category"><option>Discharge Summary</option><option>Lab Report</option><option>Scan / Image</option><option>Preauthorization</option><option>Insurance Claim</option><option>Other</option></select></div><div class="field"><label>PDF / Word / Image (max 20 MB)</label><input type="file" name="file" accept=".pdf,.doc,.docx,.png,.jpg,.jpeg,.webp" required></div><div style="align-self:end"><button class="btn teal">Upload document</button></div></form></div>''',p=p,charges=charges,docs=docs,total=total)
@app.route('/patients/<int:pid>/charges',methods=['POST'])
@login_required
def add_charge(pid):
 description=request.form.get('description','').strip()
 try:amount=float(request.form.get('amount',''))
 except ValueError:abort(400)
 if not description or amount<0:abort(400)
 with conn() as c:
  if not c.execute('SELECT 1 FROM patients WHERE id=?',(pid,)).fetchone():abort(404)
  c.execute('INSERT INTO charges(patient_id,description,amount,created_at) VALUES(?,?,?,?)',(pid,description,amount,datetime.now().isoformat(timespec='seconds')))
 return redirect(url_for('patient_detail',pid=pid))
@app.route('/charges/<int:cid>/delete',methods=['POST'])
@login_required
def delete_charge(cid):
 with conn() as c:
  r=c.execute('SELECT patient_id FROM charges WHERE id=?',(cid,)).fetchone()
  if not r:abort(404)
  c.execute('DELETE FROM charges WHERE id=?',(cid,))
 return redirect(url_for('patient_detail',pid=r['patient_id']))
@app.route('/patients/<int:pid>/documents',methods=['POST'])
@login_required
def upload_document(pid):
 f=request.files.get('file')
 if not f or not f.filename:abort(400)
 name=secure_filename(f.filename);ext=name.rsplit('.',1)[-1].lower() if '.' in name else ''
 if ext not in ALLOWED:abort(400,'Unsupported file type')
 with conn() as c:
  if not c.execute('SELECT 1 FROM patients WHERE id=?',(pid,)).fetchone():abort(404)
  stored=str(uuid.uuid4())+'.'+ext
  f.save(os.path.join(UPLOADS,stored))
  c.execute('INSERT INTO documents(patient_id,category,original_name,stored_name,uploaded_at) VALUES(?,?,?,?,?)',(pid,request.form.get('category','Other'),name,stored,datetime.now().isoformat(timespec='seconds')))
 flash('Document uploaded');return redirect(url_for('patient_detail',pid=pid))
@app.route('/documents/<int:did>')
@login_required
def download_document(did):
 with conn() as c:d=c.execute('SELECT * FROM documents WHERE id=?',(did,)).fetchone()
 if not d:abort(404)
 return send_from_directory(UPLOADS,d['stored_name'],as_attachment=True,download_name=d['original_name'])
@app.route('/documents/<int:did>/delete',methods=['POST'])
@login_required
def delete_document(did):
 with conn() as c:
  d=c.execute('SELECT * FROM documents WHERE id=?',(did,)).fetchone()
  if not d:abort(404)
  c.execute('DELETE FROM documents WHERE id=?',(did,))
 try:os.remove(os.path.join(UPLOADS,d['stored_name']))
 except FileNotFoundError:pass
 return redirect(url_for('patient_detail',pid=d['patient_id']))
@app.route('/patients/<int:pid>/invoice')
@login_required
def invoice(pid):
 with conn() as c:
  p=c.execute('SELECT * FROM patients WHERE id=?',(pid,)).fetchone()
  if not p:abort(404)
  charges=c.execute('SELECT * FROM charges WHERE patient_id=?',(pid,)).fetchall()
 total=sum(x['amount'] for x in charges)
 return page('Invoice #'+str(pid),'''<div class="card"><h2>Insurance Patient Bill</h2><p><b>Patient:</b> {{p.patient_name}} | <b>UHID:</b> {{p.uhid}} | <b>Case:</b> {{p.id}}</p><p><b>Insurer:</b> {{p.insurer}} | <b>TPA:</b> {{p.tpa or 'Direct'}} | <b>Claim:</b> {{p.claim_number or '-'}}</p><p><b>Admission:</b> {{p.admission_date or '-'}} | <b>Discharge:</b> {{p.discharge_date or '-'}}</p><div class="table-wrap"><table><tr><th>Description</th><th>Amount</th></tr>{% for x in charges %}<tr><td>{{x.description}}</td><td>{{x.amount|money}}</td></tr>{% endfor %}<tr><td><b>Total billed</b></td><td><b>{{total|money}}</b></td></tr><tr><td>Insurance approved</td><td>{{p.approved_amount|money}}</td></tr><tr><td>Insurance settled</td><td>{{p.settled_amount|money}}</td></tr></table></div><p class="muted">Generated on {{now}}. This is a billing record, not a tax-compliant invoice unless configured for the hospital's requirements.</p><button class="btn" onclick="window.print()">Print / Save PDF</button></div>''',p=p,charges=charges,total=total,now=datetime.now().strftime('%d %b %Y %H:%M'))

def filtered():
 start=request.args.get('start','');end=request.args.get('end','');name=request.args.get('name','').strip();insurer=request.args.get('insurer','').strip();kind=request.args.get('kind','');arrangement=request.args.get('arrangement','')
 clauses=['1=1'];params=[]
 for field,value,op in [('admission_date',start,'>='),('admission_date',end,'<='),('patient_name',name,'LIKE'),('insurer',insurer,'LIKE'),('admission_type',kind,'='),('insurance_type',arrangement,'=')]:
  if value:clauses.append(field+' '+op+' ?');params.append('%'+value+'%' if op=='LIKE' else value)
 sql='''SELECT p.*,COALESCE((SELECT SUM(amount) FROM charges WHERE patient_id=p.id),0) billed FROM patients p WHERE '''+' AND '.join(clauses)+' ORDER BY p.admission_date DESC,p.id DESC'
 with conn() as c:return c.execute(sql,params).fetchall()
@app.route('/reports')
@login_required
def reports():
 rows=filtered();total=sum(r['billed'] for r in rows);approved=sum(r['approved_amount'] or 0 for r in rows);settled=sum(r['settled_amount'] or 0 for r in rows)
 return page('Insurance reports','''<div class="card filters"><form method="get" class="grid"><div class="field"><label>From admission date</label><input type="date" name="start" value="{{request.args.get('start','')}}"></div><div class="field"><label>To admission date</label><input type="date" name="end" value="{{request.args.get('end','')}}"></div><div class="field"><label>Patient name</label><input name="name" value="{{request.args.get('name','')}}"></div><div class="field"><label>Insurance company</label><input name="insurer" value="{{request.args.get('insurer','')}}"></div><div class="field"><label>Patient category</label><select name="kind">{% for v in ['','IP','Day Care'] %}<option value="{{v}}" {% if request.args.get('kind','')==v %}selected{% endif %}>{{v or 'All categories'}}</option>{% endfor %}</select></div><div class="field"><label>Insurance arrangement</label><select name="arrangement">{% for v in ['','Direct','TPA'] %}<option value="{{v}}" {% if request.args.get('arrangement','')==v %}selected{% endif %}>{{v or 'All arrangements'}}</option>{% endfor %}</select></div><div class="actions wide"><button class="btn">Generate report</button><a class="btn alt" href="{{url_for('reports')}}">Reset</a><a class="btn teal" href="{{url_for('export_report',**request.args)}}">Download CSV (Excel)</a><button type="button" class="btn alt" onclick="window.print()">Print / Save PDF</button></div></form></div><div class="metrics"><div class="metric">Cases<b>{{rows|length}}</b></div><div class="metric">Billed<b>{{total|money}}</b></div><div class="metric">Approved<b>{{approved|money}}</b></div><div class="metric">Settled<b>{{settled|money}}</b></div></div><div class="card table-wrap" style="margin-top:18px"><table><tr><th>Date</th><th>Patient</th><th>UHID</th><th>Type</th><th>Insurance</th><th>Direct / TPA</th><th>Claim status</th><th>Billed</th><th>Approved</th><th>Settled</th></tr>{% for p in rows %}<tr><td>{{p.admission_date}}</td><td><a href="{{url_for('patient_detail',pid=p.id)}}">{{p.patient_name}}</a></td><td>{{p.uhid}}</td><td>{{p.admission_type}}</td><td>{{p.insurer}}</td><td>{{p.insurance_type}}{% if p.tpa %} / {{p.tpa}}{% endif %}</td><td>{{p.claim_status}}</td><td>{{p.billed|money}}</td><td>{{p.approved_amount|money}}</td><td>{{p.settled_amount|money}}</td></tr>{% endfor %}</table></div>''',rows=rows,total=total,approved=approved,settled=settled)
@app.route('/reports/export')
@login_required
def export_report():
 out=io.StringIO();writer=csv.writer(out);writer.writerow(['Admission Date','Patient Name','UHID','IP / Day Care','Insurer','Direct / TPA','TPA Name','Policy Number','Claim Number','Claim Status','Billed','Approved','Settled'])
 for p in filtered():writer.writerow([p[k] for k in ['admission_date','patient_name','uhid','admission_type','insurer','insurance_type','tpa','policy_number','claim_number','claim_status','billed','approved_amount','settled_amount']])
 return Response('\ufeff'+out.getvalue(),mimetype='text/csv',headers={'Content-Disposition':'attachment; filename=insurance_report.csv'})
if __name__=='__main__':
 import socket, threading, time, webbrowser
 from waitress import serve
 host='127.0.0.1'
 with socket.socket() as sock:
  sock.bind((host,0))
  port=sock.getsockname()[1]
 url=f'http://{host}:{port}/setup' if not admin_exists() else f'http://{host}:{port}/login'
 print(f'Akverix MedClaim running at {url}',flush=True)
 print(f'Patient data folder: {DATA}',flush=True)
 print('Keep this window open while using the application.',flush=True)
 def launch():
  time.sleep(1.2)
  webbrowser.open(url)
 threading.Thread(target=launch,daemon=True).start()
 serve(app,host=host,port=port,threads=4)

