@echo off
setlocal
set "DATA=%LOCALAPPDATA%\AkverixMedClaim"
if not exist "%DATA%\hospital.db" (echo No existing database found. & pause & exit /b 0)
echo ONLY USE THIS ON AN UNUSED INSTALLATION WITH NO REAL PATIENT DATA.
echo Close the application first. The old data folder will be backed up.
set /p "CONFIRM=Type RESET to continue: "
if /I not "%CONFIRM%"=="RESET" exit /b 1
set "BACKUP=%LOCALAPPDATA%\AkverixMedClaim_backup_%RANDOM%_%RANDOM%"
move "%DATA%" "%BACKUP%"
if errorlevel 1 (echo Failed. Close application and retry.) else (echo Backup saved to: %BACKUP%)
pause
